### 하루 감정 강도 요약

| 씬 | 주요 감정 | 세부 묘사 | 강도(1~10) |
|---|---|---|---|
| Scene 3. 길고양이 길드 결성 | 기대/흥분, 자신감, 전략적 집중 | 퀘스트 공지로 스스로 고양, 치킨 보상으로 동기 상승, 지안 설득 중 계산적 태도, 첫 스카우트 직전 심박 상승 | 8 |

### Mermaid 그래프

```mermaid
xychart-beta
    title: Haru Emotion Intensity by Scene
    x-axis: Scene
    y-axis: Intensity (1-10)
    series:
      - title: Emotion
        data:
          - x: 3
            y: 8
```


